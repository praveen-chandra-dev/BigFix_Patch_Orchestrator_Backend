// bigfix-backend/src/services/bigfix.js
const axios = require("axios");
const { collectStrings } = require("../utils/query");
const { getBfAuthContext } = require("../utils/http");

const bigfixClient = (req, ctx) => { // SECURE: MUST ACCEPT REQ
  const config = ctx.bigfix || {};
  const BIGFIX_BASE_URL = config.BIGFIX_BASE_URL || process.env.BIGFIX_BASE_URL;

  if (!BIGFIX_BASE_URL) throw new Error("BigFix URL not configured");

  async function getGroupMembers(groupName) {
    const relevance = `(name of it, (value of result (it, bes property "Patch_Setu_IP_Address") | "N/A"), (operating system of it | "Unknown")) of members whose (value of result (it, bes property "Device Type") as lowercase = "server") of bes computer group whose (name of it = "${groupName}")`;
    
    try {
      // DYNAMICALLY FETCH AUTH FOR THIS SPECIFIC USER
      const bfAuthOpts = await getBfAuthContext(req, ctx); 
      
      const res = await axios.get(`${BIGFIX_BASE_URL}/api/query`, {
        ...bfAuthOpts,
        params: { output: "json", relevance }
      });

      const rows = res.data?.result || [];
      return rows.map(r => {
        const parts = [];
        collectStrings(r, parts);
        const [name, ipStr, os] = parts;
        return {
          name: name || "Unknown",
          ips: (ipStr || "").split(";").filter(Boolean),
          os: os || "Unknown" 
        };
      });
    } catch (err) {
      const msg = err.response?.data ? JSON.stringify(err.response.data) : err.message;
      throw new Error(`Failed to fetch members for group ${groupName}: ${msg}`);
    }
  }

  return { getGroupMembers };
};

module.exports = { bigfixClient };