// src/routes/groups.js
const axios = require("axios");
const { joinUrl } = require("../utils/http");
const { logFactory } = require("../utils/log");
const { sql, getPool } = require("../db/mssql");
const { bigfixClient } = require("../services/bigfix");
const { getBfAuthContext } = require("../utils/http");

const CACHE_TTL = 10 * 60 * 1000; // 10 Minutes
let userComputersCache = {};

function getSessionUser(req) {
    if (req && req.cookies && req.cookies.auth_session) {
        try { return JSON.parse(req.cookies.auth_session).username; } catch(e){}
    }
    return "unknown";
}

const xmlEscape = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");

// --- Helper: Dynamically check if the user is a Master Operator ---
async function isMasterOperator(req, ctx, operatorName) {
    try {
        const { BIGFIX_BASE_URL } = ctx.bigfix;
        const bfAuthOpts = await getBfAuthContext(req, ctx);
        
        // 1. Check via Operator API
        const url = joinUrl(BIGFIX_BASE_URL, `/api/operator/${encodeURIComponent(operatorName)}`);
        const resp = await axios.get(url, { ...bfAuthOpts, headers: { Accept: "application/xml" }, validateStatus: () => true });
        
        if (resp.status === 200) {
            const xml = String(resp.data || "");
            const match = xml.match(/<MasterOperator>(.*?)<\/MasterOperator>/i);
            if (match) {
                return match[1].trim().toLowerCase() === "true" || match[1].trim() === "1";
            }
        }
        
        // 2. Safe Fallback: Check via Session Relevance if API fails
        const relUrl = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent("master flag of current console user")}`;
        const relResp = await axios.get(relUrl, { ...bfAuthOpts, headers: { Accept: "application/json" }, validateStatus: () => true });
        
        if (relResp.status === 200 && relResp.data?.result) {
            const resStr = String(relResp.data.result[0] || relResp.data.result).trim().toLowerCase();
            if (resStr === "true") return true;
        }
        
        return false;
    } catch (e) {
        console.warn(`[GroupSync] Failed to check MasterOperator status for ${operatorName}:`, e.message);
        return false; 
    }
}

// --- NEW HELPER: Get Property ID by Name ---
async function getPropertyIdByName(req, ctx, propertyName) {
    const { BIGFIX_BASE_URL } = ctx.bigfix;
    const bfAuthOpts = await getBfAuthContext(req, ctx);
    const safeName = propertyName.toLowerCase().replace(/"/g, '""');
    
    // First try to find a reserved (native) property
    let relevance = `(item 1 of it) of ids of bes properties whose (name of it as lowercase = "${safeName}" and reserved flag of it = true)`;
    try {
        let url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
        let resp = await axios.get(url, { ...bfAuthOpts, headers: { Accept: "application/json" } });
        let result = resp.data?.result;
        let raw = Array.isArray(result) ? result : (result ? [result] : []);
        if (raw.length > 0) return String(raw[0]);
        
        // Fallback: If not a reserved property, check custom properties
        relevance = `(item 1 of it) of ids of bes properties whose (name of it as lowercase = "${safeName}")`;
        url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
        resp = await axios.get(url, { ...bfAuthOpts, headers: { Accept: "application/json" } });
        result = resp.data?.result;
        raw = Array.isArray(result) ? result : (result ? [result] : []);
        if (raw.length > 0) return String(raw[0]);

    } catch (e) {
        console.warn(`[GroupSync] Failed to get Property ID for ${propertyName}:`, e.message);
    }
    return null;
}

// --- Helper: Verify which IDs actually exist in BigFix ---
async function verifyBigFixIds(req, ctx, ids) {
  if (!ids || ids.length === 0) return [];
  const { BIGFIX_BASE_URL } = ctx.bigfix;
  
  const setStr = ids.join("; ");
  const relevance = `unique values of ids of bes computer groups whose (id of it is contained by set of (${setStr}))`;
  let foundIds = [];
  try {
    const url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
      const bfAuthOpts = await getBfAuthContext(req, ctx);
      const resp = await axios.get(url, {
          ...bfAuthOpts,
          headers: { Accept: "application/json" }
      });    
      const result = resp.data?.result;
    if (Array.isArray(result)) result.forEach(r => foundIds.push(String(r)));
    else if (result) foundIds.push(String(result));
  } catch (e) { console.warn("[GroupSync] Relevance check failed:", e.message); }
  
  const missing = ids.filter(id => !foundIds.includes(String(id)));
  if (missing.length > 0) {
    try {
        const restUrl = joinUrl(BIGFIX_BASE_URL, "/api/computergroups/master");
        const bfAuthOpts = await getBfAuthContext(req, ctx);
        const restResp = await axios.get(restUrl, { ...bfAuthOpts, headers: { Accept: "application/xml" }, validateStatus: (s) => s < 500 });
        if (restResp.status === 200) {
            const xml = String(restResp.data || "");
            const regex = /<ID>(\d+)<\/ID>/gi;
            let match;
            while ((match = regex.exec(xml)) !== null) {
                if (missing.includes(match[1])) foundIds.push(match[1]);
            }
        }
    } catch (e) { console.warn("[GroupSync] Master check failed:", e.message); }
  }
  return foundIds;
}

function attachGroupRoutes(app, ctx) {
  const log = logFactory(ctx.DEBUG_LOG);
  const { BIGFIX_BASE_URL } = ctx.bigfix;

  // --- 1. LIST GROUPS (With Smart Sync) ---
  app.get("/api/groups/list", async (req, res) => {
    try {
      const userRole = req.headers['x-user-role'] || 'Admin';
      const pool = await getPool();
      
      let query = "SELECT BigFixID, AssetName, CreatedByRole, CreatedAt FROM dbo.AssetOwnership WHERE AssetType='Group'";
      if (userRole !== 'Admin') query += " AND CreatedByRole = @Role";
      const reqSql = pool.request();
      if (userRole !== 'Admin') reqSql.input('Role', sql.NVarChar(50), userRole);
      
      const dbRes = await reqSql.query(query);
      let dbGroups = dbRes.recordset;

      if (dbGroups.length > 0) {
        const localIds = dbGroups.map(g => g.BigFixID);
        const realIds = await verifyBigFixIds(req, ctx, localIds);
        const zombies = dbGroups.filter(g => !realIds.includes(String(g.BigFixID)));
        
        if (zombies.length > 0) {
          const idsToDelete = [];
          const now = Date.now();
          const GRACE_PERIOD_MS = 60 * 60 * 1000; 

          for (const z of zombies) {
             const createdTime = z.CreatedAt ? new Date(z.CreatedAt).getTime() : 0;
             if (now - createdTime > GRACE_PERIOD_MS) {
                idsToDelete.push(z.BigFixID);
             }
          }

          if (idsToDelete.length > 0) {
             console.log(`[GroupSync] Cleaning up ${idsToDelete.length} deleted groups.`);
             for (const zId of idsToDelete) {
                await pool.request().input('ZID', sql.NVarChar(255), String(zId)).query("DELETE FROM dbo.AssetOwnership WHERE BigFixID = @ZID");
             }
             dbGroups = dbGroups.filter(g => !idsToDelete.includes(String(g.BigFixID)));
          }
        }
      }

      const results = dbGroups.map(g => ({ id: g.BigFixID, name: g.AssetName, ownerRole: g.CreatedByRole }));
      res.json({ ok: true, groups: results });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
  });

  // --- 2. CREATE GROUP ---
  app.post("/api/groups/create", async (req, res) => {
    const { name, type, targetSite, conditions, computerIds } = req.body;
    const userRole = req.headers['x-user-role'] || 'Admin';
    if (!name) return res.status(400).json({ ok: false, error: "Group name is required" });
    
    try {
        const bfAuthOpts = await getBfAuthContext(req, ctx);
        const operatorName = bfAuthOpts.auth.username;

        let endpoint = "", xmlBody = "";
        
        if (type === "Manual") {
            if (!computerIds?.length) return res.status(400).json({ok:false, error: "No computers selected"});
            
            const isMO = await isMasterOperator(req, ctx, operatorName);
            endpoint = isMO ? "/api/computergroup/master" : `/api/computergroup/operator/${encodeURIComponent(operatorName)}`;
            
            const computerTags = computerIds.map(id => `<ComputerID>${id}</ComputerID>`).join("\n");
            xmlBody = `<?xml version="1.0" encoding="UTF-8"?><BESAPI xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="BESAPI.xsd"><ManualComputerGroup><Name>${xmlEscape(name)}</Name><EvaluateOnClient>false</EvaluateOnClient>${computerTags}</ManualComputerGroup></BESAPI>`;
        
        } else if (type === "ServerBased") {
            // NEW: DYNAMIC PROPERTY ID LOOKUP FOR SERVER BASED GROUPS
            if (!conditions?.length) return res.status(400).json({ok:false, error: "No conditions provided"});
            
            const sitePath = targetSite ? `/custom/${encodeURIComponent(targetSite)}` : "/master";
            endpoint = `/api/computergroup${sitePath}`;
            
            let searchComponents = "";
            for (const cond of conditions) {
                const propId = await getPropertyIdByName(req, ctx, cond.property);
                if (!propId) {
                    throw new Error(`Could not resolve BigFix Property ID for '${cond.property}'. Please ensure this property exists.`);
                }
                searchComponents += `<MembershipRule Comparison="${xmlEscape(cond.operator)}"><PropertyID>${xmlEscape(propId)}</PropertyID><SearchText>${xmlEscape(cond.value)}</SearchText></MembershipRule>`;
            }
            
            xmlBody = `<?xml version="1.0" encoding="UTF-8"?><BESAPI xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="BESAPI.xsd"><ServerBasedGroup><Name>${xmlEscape(name)}</Name><MembershipRules JoinByIntersection="true">${searchComponents}</MembershipRules></ServerBasedGroup></BESAPI>`;
        
        } else {
            if (!conditions?.length) return res.status(400).json({ok:false, error: "No conditions provided"});
            const sitePath = targetSite ? `/custom/${encodeURIComponent(targetSite)}` : "/master";
            endpoint = `/api/computergroup${sitePath}`;
            const searchComponents = conditions.map(cond => `<SearchComponentPropertyReference PropertyName="${xmlEscape(cond.property)}" Comparison="${xmlEscape(cond.operator)}"><SearchText>${xmlEscape(cond.value)}</SearchText><Relevance></Relevance></SearchComponentPropertyReference>`).join("");
            xmlBody = `<BES xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="BES.xsd"><ComputerGroup><Title>${xmlEscape(name)}</Title><JoinByIntersection>true</JoinByIntersection>${searchComponents}</ComputerGroup></BES>`;
        }

        const postUrl = joinUrl(BIGFIX_BASE_URL, endpoint);
        const bfResp = await axios.post(postUrl, xmlBody, { ...bfAuthOpts, responseType: 'text', headers: { ...bfAuthOpts.headers, "Content-Type": "application/xml" } });
        
        let newId = null, rawStr = String(bfResp.data || "").trim();
        let idMatch = rawStr.match(/<ID>\s*(\d+)\s*<\/ID>/i);
        if (idMatch) newId = idMatch[1];
        if (!newId) { idMatch = rawStr.match(/Resource=["'].*?\/(\d+)["']/i); if (idMatch) newId = idMatch[1]; }
        if (!newId) { idMatch = rawStr.match(/\/(\d+)\s*$/); if (idMatch) newId = idMatch[1]; }
        
        if (newId) {
            const pool = await getPool();
            await pool.request().input('BigFixID', sql.NVarChar(255), String(newId)).input('AssetName', sql.NVarChar(255), name).input('AssetType', sql.NVarChar(50), 'Group').input('CreatedByRole', sql.NVarChar(50), userRole).query(`INSERT INTO dbo.AssetOwnership (BigFixID, AssetName, AssetType, CreatedByRole, CreatedAt) VALUES (@BigFixID, @AssetName, @AssetType, @CreatedByRole, SYSUTCDATETIME())`);
            res.json({ ok: true, id: newId });
        } else {
            throw new Error("Group created but ID parse failed.");
        }
    } catch (e) { res.status(500).json({ ok: false, error: e.response?.data || e.message }); }
  });

  // --- 3. DELETE GROUP ---
  app.delete("/api/groups/:id", async (req, res) => {
    const { id } = req.params;
    const userRole = req.headers['x-user-role'] || 'Admin';
    try {
      const pool = await getPool();
      if (userRole !== 'Admin') {
        const check = await pool.request().input('ID', sql.NVarChar(255), id).query("SELECT CreatedByRole FROM dbo.AssetOwnership WHERE BigFixID = @ID");
        if (!check.recordset.length || check.recordset[0].CreatedByRole !== userRole) return res.status(403).json({ ok: false, error: "Permission Denied" });
      }
      
      const bfAuthOpts = await getBfAuthContext(req, ctx);
      const url = joinUrl(BIGFIX_BASE_URL, `/api/computergroup/master/${id}`);
      
      try { await axios.delete(url, bfAuthOpts); } catch (e) { 
          try {
             const operatorName = bfAuthOpts.auth.username;
             const opUrl = joinUrl(BIGFIX_BASE_URL, `/api/computergroup/operator/${encodeURIComponent(operatorName)}/${id}`);
             await axios.delete(opUrl, bfAuthOpts);
          } catch(err) { /* ignore */ }
      }
      
      await pool.request().input('ID', sql.NVarChar(255), id).query("DELETE FROM dbo.AssetOwnership WHERE BigFixID = @ID");
      res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
  });

  // --- 4. LIST COMPUTERS (Updated for EUC Separation) ---
  app.get("/api/groups/metadata/computers", async (req, res) => {
      try {
        const userRole = req.headers['x-user-role'] || 'Admin';
        const activeUser = getSessionUser(req);
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 20;
        const search = (req.query.search || "").toLowerCase();

        let computerList = [];
        const bfAuthOpts = await getBfAuthContext(req, ctx);

        if (userRole === 'EUC') {
            const relevance = `(id of it as string & "||" & name of it as string & "||" & (value of result (it, bes property "Patch_Setu_IP_Address") | "N/A") & "||" & (operating system of it as string | "Unknown")) of bes computers whose (value of result (it, bes property "Device Type") as lowercase != "server")`;
            
            const url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
            const resp = await axios.get(url, bfAuthOpts);
            const raw = Array.isArray(resp.data?.result) ? resp.data.result : [];
            
            computerList = raw.map(r => { 
                const p = String(r).split("||"); 
                const ipStr = p[2] === "N/A" ? "" : p[2];
                return { 
                  id: p[0], 
                  name: p[1], 
                  ips: ipStr.split(/[;,]/).map(x => x.trim()).filter(Boolean),
                  os: p[3]
                }; 
            });

        } else {
            if (!userComputersCache[activeUser]) {
                userComputersCache[activeUser] = { data: [], lastFetch: 0 };
            }
            const cache = userComputersCache[activeUser];

            const now = Date.now();
            if ((now - cache.lastFetch > CACHE_TTL) || !cache.data.length) {
                const relevance = `(id of it as string & "||" & name of it as string & "||" & (value of result (it, bes property "Patch_Setu_IP_Address") | "N/A") & "||" & (operating system of it as string | "Unknown")) of bes computers whose (value of result (it, bes property "Device Type") as lowercase = "server")`;
    
                const url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
                const resp = await axios.get(url, bfAuthOpts);
                const raw = Array.isArray(resp.data?.result) ? resp.data.result : [];
                
                cache.data = raw.map(r => { 
                    const p = String(r).split("||"); 
                    const ipStr = p[2] === "N/A" ? "" : p[2];
                    return { 
                      id: p[0], 
                      name: p[1], 
                      ips: ipStr.split(/[;,]/).map(x => x.trim()).filter(Boolean),
                      os: p[3]
                    }; 
                });
                cache.lastFetch = now;
            }
            
            computerList = cache.data;

            if (userRole === 'Windows') {
                computerList = computerList.filter(c => c.os && c.os.toLowerCase().includes("win"));
            } else if (userRole === 'Linux') {
                computerList = computerList.filter(c => c.os && !c.os.toLowerCase().includes("win"));
            }
        }

        if (search) {
            computerList = computerList.filter(c => 
                c.name.toLowerCase().includes(search) || 
                c.ips.some(ip => ip.includes(search)) ||
                (c.os && c.os.toLowerCase().includes(search))
            );
        }

        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + limit;
        const resultSlice = computerList.slice(startIndex, endIndex);

        res.json({ 
            ok: true, 
            computers: resultSlice,
            total: computerList.length,
            page,
            totalPages: Math.ceil(computerList.length / limit)
        });

      } catch (e) { res.status(500).json({ok:false, error:e.message}); }
  });

  // --- 5. GET GROUP MEMBERS ---
  app.get("/api/groups/:name/members", async (req, res) => {
    req._logStart = Date.now();
    try {
      const userRole = req.headers['x-user-role'] || 'Admin';
      const client = bigfixClient(req, ctx); 
      let members = await client.getGroupMembers(req.params.name);
      
      if (userRole === 'Windows') {
          members = members.filter(m => m.os && m.os.toLowerCase().includes("win"));
      } else if (userRole === 'Linux') {
          members = members.filter(m => m.os && !m.os.toLowerCase().includes("win"));
      }

      res.json({ ok: true, members });
    } catch (e) {
      log(req, "Group Members Error:", e.message);
      res.status(500).json({ ok: false, error: e.message });
    }
  });

  // --- 6. PROPERTIES ---
  app.get("/api/groups/metadata/properties", async (req, res) => {
      try {
        const bfAuthOpts = await getBfAuthContext(req, ctx);
        const relevance = `(((item 1 of it) of id of it as string | "N/A") & "||" & (name of it as string | "N/A")) of bes properties whose (reserved flag of it is true)`;
        const url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
        const resp = await axios.get(url, bfAuthOpts);
        const raw = Array.isArray(resp.data?.result) ? resp.data.result : [];
        const properties = raw.map(r => String(r).split("||")[1] || "Unknown").sort();
        res.json({ ok: true, properties: [...new Set(properties)] });
      } catch (e) { res.status(500).json({ok:false, error:e.message}); }
  });
}

module.exports = { attachGroupRoutes };