// src/routes/health.js
const axios = require("axios");
const { parseTupleRows } = require("../utils/query");
const { joinUrl } = require("../utils/http");
const { actionStore, CONFIG } = require("../state/store");
const { logFactory } = require("../utils/log");
const { getBfAuthContext } = require("../utils/http");

function getThresholdMilliseconds(value, unit) {
  const v = Math.max(0, Number(value) || 0);
  switch (String(unit).toLowerCase()) {
    case "minutes": return v * 60 * 1000;
    case "hours": return v * 60 * 60 * 1000;
    case "days": default: return v * 24 * 60 * 60 * 1000;
  }
}

function isTimeUnhealthy(timeString, thresholdMs) {
  if (!timeString || timeString === "N/A") return true;
  try {
    const parsableDate = timeString.substring(timeString.indexOf(", ") + 2);
    const lastReportTime = Date.parse(parsableDate);
    if (isNaN(lastReportTime)) return true;
    return (Date.now() - lastReportTime) > thresholdMs;
  } catch { return true; }
}

function attachHealthRoutes(app, ctx) {
  const log = logFactory(ctx.DEBUG_LOG);
  const { BIGFIX_BASE_URL } = ctx.bigfix;

  app.get("/health", (req, res) => { res.json({ ok: true, ts: new Date().toISOString() }); });

  function getBaseComputers(groupName) {
      if (groupName) {
          const safeGroup = String(groupName).replace(/"/g, '""').toLowerCase();
          return `members of bes computer groups whose (name of it as lowercase = "${safeGroup}")`;
      }
      return `bes computers`;
  }

  function getRoleFilter(req) {
    const userRole = req.headers['x-user-role'] || 'Admin';
    let conditions = [];
    if (userRole === 'Windows') conditions.push(`(operating system of it as lowercase contains "win")`);
    else if (userRole === 'Linux') conditions.push(`(operating system of it as lowercase does not contain "win")`);
    else if (userRole === 'EUC') conditions.push(`(value of result (it, bes property "Device Type") as lowercase != "server")`);
    return conditions.length > 0 ? ` whose (${conditions.join(" and ")})` : "";
  }

  app.get("/api/infra/total-computers", async (req, res) => {
    try {
      const baseComp = getBaseComputers(req.query.group);
      const filter = getRoleFilter(req);
      const relevance = `number of ${baseComp}${filter}`;
      const url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
      
      const bfAuthOpts = await getBfAuthContext(req, ctx); // SECURE CONTEXT
      const resp = await axios.get(url, { ...bfAuthOpts, headers: { Accept: "application/json" }, validateStatus: () => true });

      if (resp.status < 200 || resp.status >= 300) return res.status(resp.status).send(resp.data);

      let total = 0;
      const data = resp.data;
      if (data && data.result && Array.isArray(data.result) && data.result[0]) {
        const tuple = data.result[0].Tuple || data.result[0].tuple || data.result[0];
        const m = String(Array.isArray(tuple) ? tuple[0] : tuple).match(/\d+/);
        if (m) total = Number(m[0]);
      }
      if (!total) {
        const m = JSON.stringify(resp.data).match(/\b\d+\b/);
        if (m) total = Number(m[0]);
      }
      res.json({ ok: true, total });
    } catch (err) { res.status(500).json({ ok: false, error: err.message }); }
  });

  app.get("/api/health/critical", async (req, res) => {
    try {
      const baseComp = getBaseComputers(req.query.group);
      const filter = getRoleFilter(req);
      const userRole = req.headers['x-user-role'] || 'Admin';
      
      const relevance = '((name of it | "N/A") , (value of result (it, bes property "Patch_Setu_Disk_Space") | "N/A"), (value of result (it, bes property "Patch_Setu_IP_Address") | "N/A"), (last report time of it as string | "N/A"), (value of result (it, bes property "Patch_Setu_Window_Update_Service") | "N/A"), (operating system of it | "N/A"))' + ` of ${baseComp}${filter}`;
      const url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
      
      const bfAuthOpts = await getBfAuthContext(req, ctx); // SECURE CONTEXT
      const resp = await axios.get(url, { ...bfAuthOpts, headers: { Accept: "application/json" }, validateStatus: () => true });

      if (resp.status < 200 || resp.status >= 300) return res.status(resp.status).send(resp.data);

      const tuples = parseTupleRows(resp.data);
      const afterEq = (s) => { const str = String(s || "").trim(); const idx = str.indexOf("="); return idx >= 0 ? str.slice(idx + 1).trim() : str; };
      const parseDiskGB = (s) => { const m = String(s || "").match(/(\d+(?:\.\d+)?)\s*GB/i); return m ? Number(m[1]) : null; };

      const parsed = tuples.map((parts) => {
        const diskPretty = afterEq(parts[1]) || "N/A";
        return { server: afterEq(parts[0]) || "N/A", disk: diskPretty, diskGB: parseDiskGB(diskPretty), ip: afterEq(parts[2]) || "N/A", lastReportTime: parts[3] || "N/A", serviceStatus: parts[4] || "N/A", os: parts[5] || "N/A", raw: parts };
      });

      const DSK_T = Number(CONFIG.diskThresholdGB);
      const thresholdMs = getThresholdMilliseconds(CONFIG.lastReportValue, CONFIG.lastReportUnit);

      const rows = parsed.map((r) => {
        const issues = [];
        if (r.diskGB != null && r.diskGB <= DSK_T) issues.push(`Low Disk (${r.diskGB}GB)`);
        if (isTimeUnhealthy(r.lastReportTime, thresholdMs)) issues.push("Not Reporting");
        if (CONFIG.checkServiceStatus && String(r.os).toLowerCase().includes("win") && userRole !== 'EUC' && r.serviceStatus.toLowerCase() !== "running") issues.push(`Service ${r.serviceStatus}`);
        
        return issues.length > 0 ? { ...r, issues } : null;
      }).filter(Boolean);

      res.json({ ok: true, count: rows.length, rows });
    } catch (err) { res.status(500).json({ ok: false, error: err.message }); }
  });

  app.get("/api/health/reboot-pending", async (req, res) => {
    try {
      const baseComp = getBaseComputers(req.query.group);
      const filter = getRoleFilter(req);
      const relevance = '((name of it | "N/A"), (value of result (it, bes property "Patch_Setu_Pending_Restart") | "N/A"), (last report time of it as string | "N/A"), (value of result (it, bes property "Patch_Setu_Disk_Space") | "N/A"), (value of result (it, bes property "Patch_Setu_IP_Address") | "N/A"), (value of result (it, bes property "Patch_Setu_UpTime") | "N/A"), (value of result (it, bes property "BES Relay Service Installed") | "N/A")) ' + `of ${baseComp}${filter}`;
      const url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
      
      const bfAuthOpts = await getBfAuthContext(req, ctx); // SECURE CONTEXT
      const resp = await axios.get(url, { ...bfAuthOpts, headers: { Accept: "application/json" } });
      if (resp.status < 200 || resp.status >= 300) return res.status(resp.status).send(resp.data);

      const tuples = parseTupleRows(resp.data);
      const rows = tuples.map((parts) => {
          if (!Array.isArray(parts) || parts.length < 7) return null;
          const [server, pendingStr, lastReportTime, diskStr, ipStr, uptime, besRelay] = parts;
          return { server: server || "N/A", pendingRestart: /^true$/i.test(String(pendingStr).trim()), lastReportTime: lastReportTime || "N/A", disk: String(diskStr || "").trim() || "N/A", ip: String(ipStr || "").replace(/^IP Address\s*=\s*/i, "").split(",")[0].trim() || "N/A", uptime: uptime || "N/A", besRelay: besRelay || "N/A", raw: parts };
        }).filter(r => r && r.pendingRestart === true);

      res.json({ ok: true, count: rows.length, rows });
    } catch (err) { res.status(500).json({ ok: false, error: err.message }); }
  });
}

module.exports = { attachHealthRoutes };