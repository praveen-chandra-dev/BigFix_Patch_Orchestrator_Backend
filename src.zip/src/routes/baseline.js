// src/routes/baseline.js
const axios = require("axios");
const { joinUrl } = require("../utils/http");
const { logFactory } = require("../utils/log");
const { sql, getPool } = require("../db/mssql");
const { getBfAuthContext } = require("../utils/http");

// --- Helper: Verify if Baseline IDs exist using USER CONTEXT ---
async function verifyBigFixBaselines(req, ctx, ids) {
  if (!ids || ids.length === 0) return [];
  const { BIGFIX_BASE_URL } = ctx.bigfix;
  
  const setStr = ids.join("; ");
  const relevance = `unique values of ids of bes baselines whose (id of it is contained by set of (${setStr}))`;
  
  try {
    const url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
    const bfAuthOpts = await getBfAuthContext(req, ctx); // SECURE CONTEXT
    
    const resp = await axios.get(url, {
        ...bfAuthOpts,
        headers: { Accept: "application/json" }
    });
    const result = resp.data?.result;
    const foundIds = [];
    if (Array.isArray(result)) result.forEach(r => foundIds.push(String(r)));
    else if (result) foundIds.push(String(result));
    
    return foundIds;
  } catch (e) {
    console.warn("[BaselineSync] Failed to verify IDs:", e.message);
    return ids.map(String); 
  }
}

function attachBaselineRoutes(app, ctx) {
  const log = logFactory(ctx.DEBUG_LOG);
  const { BIGFIX_BASE_URL } = ctx.bigfix;

  app.get("/api/baselines/list", async (req, res) => {
      try {
        const userRole = req.headers['x-user-role'] || 'Admin';
        const pool = await getPool();
        
        let query = "SELECT BigFixID, AssetName, CreatedByRole, CreatedAt FROM dbo.AssetOwnership WHERE AssetType='Baseline'";
        if (userRole !== 'Admin') query += " AND CreatedByRole = @Role";

        const reqSql = pool.request();
        if (userRole !== 'Admin') reqSql.input('Role', sql.NVarChar(50), userRole);
        
        const dbRes = await reqSql.query(query);
        let dbRows = dbRes.recordset;

        if (dbRows.length > 0) {
            const now = new Date();
            const SAFE_WINDOW_MS = 10 * 60 * 1000; 
            const candidates = dbRows.filter(r => (now - new Date(r.CreatedAt)) > SAFE_WINDOW_MS);

            if (candidates.length > 0) {
                const localIdsToCheck = candidates.map(r => r.BigFixID);
                const realIds = await verifyBigFixBaselines(req, ctx, localIdsToCheck); // PASS REQ
                const zombies = localIdsToCheck.filter(id => !realIds.includes(String(id)));

                if (zombies.length > 0) {
                    for (const zId of zombies) {
                        await pool.request().input('ZID', sql.NVarChar(255), String(zId)).query("DELETE FROM dbo.AssetOwnership WHERE BigFixID = @ZID AND AssetType='Baseline'");
                    }
                    dbRows = dbRows.filter(r => !zombies.includes(r.BigFixID));
                }
            }
        }
        res.json({ ok: true, baselines: dbRows.map(r => ({ id: r.BigFixID, name: r.AssetName })) });
      } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
  });

  app.get("/api/baseline/sites", async (req, res) => {
    try {
      const userRole = req.headers['x-user-role'] || 'Admin';
      let filter = "";
      if (userRole === 'Windows') filter = ` AND (display name of it as lowercase contains "windows")`;
      else if (userRole === 'Linux') filter = ` AND (display name of it as lowercase does not contain "windows")`;

      const relevance = `display names of bes sites whose((display name of it contains "Patch" or display name of it contains "Updates")${filter})`;
      const url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
      
      const bfAuthOpts = await getBfAuthContext(req, ctx); // SECURE CONTEXT
      const resp = await axios.get(url, { ...bfAuthOpts, headers: { Accept: "application/json" } });
      
      let results = resp.data?.result || [];
      if (!Array.isArray(results)) results = [results];
      results.sort((a, b) => String(a).localeCompare(String(b)));
      res.json({ ok: true, sites: results });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
  });

  app.get("/api/baseline/custom-sites", async (req, res) => {
    try {
      const relevance = `names of bes custom sites`;
      const url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
      
      const bfAuthOpts = await getBfAuthContext(req, ctx); // SECURE CONTEXT
      const resp = await axios.get(url, { ...bfAuthOpts, headers: { Accept: "application/json" } });

      let results = resp.data?.result || [];
      if (!Array.isArray(results)) results = [results];
      results.sort();
      res.json({ ok: true, sites: results });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
  });

  app.get("/api/baseline/patches", async (req, res) => {
    const { site } = req.query;
    if (!site) return res.status(400).json({ ok: false, error: "Site parameter required" });
    try {
      const safeSite = site.replace(/"/g, '%22');
      const relevance = `((id of it as string | "N/A") & " | " & (name of it | "N/A") & " | " & (display name of site of it as string | "N/A") & " | " & (source severity of it | "N/A")) of bes fixlets whose(display name of site of it is "${safeSite}" and applicable computer count of it > 0 and fixlet flag of it and exists default action of it)`;      
      const url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
      
      const bfAuthOpts = await getBfAuthContext(req, ctx); // SECURE CONTEXT
      const resp = await axios.get(url, { ...bfAuthOpts, headers: { Accept: "application/json" } });
      
      let rawResults = resp.data?.result || [];
      if (!Array.isArray(rawResults)) rawResults = [rawResults];
      const patches = rawResults.map((str) => {
        const parts = String(str).split(" | ");
        return { id: parts[0] || "N/A", name: parts[1] || "N/A", site: parts[2] || safeSite, severity: parts[3] || "Unspecified" };
      });
      res.json({ ok: true, count: patches.length, patches });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
  });

  app.post("/api/baseline/create", async (req, res) => {
    const { baselineName, targetSite, patchKeys } = req.body;
    const userRole = req.headers['x-user-role'] || 'Admin'; 

    if (!baselineName || !targetSite || !Array.isArray(patchKeys) || patchKeys.length === 0) return res.status(400).json({ ok: false, error: "Missing required fields." });
    try {
      const bfAuthOpts = await getBfAuthContext(req, ctx); // SECURE CONTEXT

      const siteToIds = new Map();
      for (const key of patchKeys) {
        const [idRaw, siteRaw] = String(key).split("||");
        const id = idRaw && idRaw.trim();
        const siteName = siteRaw && siteRaw.trim();
        if (!id || !siteName) continue;
        if (!siteToIds.has(siteName)) siteToIds.set(siteName, new Set());
        siteToIds.get(siteName).add(id);
      }
      if (siteToIds.size === 0) throw new Error("No valid keys provided.");
      
      const patchMap = new Map();
      for (const [siteName, idsSet] of siteToIds.entries()) {
        const idsStr = Array.from(idsSet).join(";");
        const safeSite = siteName.replace(/"/g, '%22');
        const relevance = `("ID: " & (id of it as string | "N/A") & " || SourceURL: " & (url of site of it as string | "N/A") & " || Site: " & (display name of site of it | "N/A")) of bes fixlets whose (display name of site of it = "${safeSite}" and id of it is contained by set of (${idsStr}))`;
        const qUrl = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
        
        const qResp = await axios.get(qUrl, { ...bfAuthOpts, headers: { Accept: "application/json" } });
        let queryResults = qResp.data?.result || [];
        if (!Array.isArray(queryResults)) queryResults = [queryResults];
        queryResults.forEach((row) => {
          const parts = String(row).split(" || ");
          if (parts.length >= 3) {
            const idPart = parts[0].replace("ID: ", "").trim();
            const urlPart = parts[1].replace("SourceURL: ", "").trim();
            const sitePart = parts[2].replace("Site: ", "").trim();
            if (idPart && urlPart && sitePart) patchMap.set(`${idPart}||${sitePart}`, urlPart);
          }
        });
      }

      let componentsXml = "";
      for (const key of patchKeys) {
        const [idStr, siteName] = String(key).split("||");
        if (!idStr || !siteName) continue;
        const sourceUrl = patchMap.get(`${idStr.trim()}||${siteName.trim()}`);
        if (sourceUrl) componentsXml += `<BaselineComponent IncludeInRelevance="true" SourceSiteURL="${sourceUrl}" SourceID="${idStr.trim()}" ActionName="Action1" />`;
      }
      if (!componentsXml) throw new Error("No valid components generated.");

      const xmlEscape = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      const finalXml = `<?xml version="1.0" encoding="UTF-8"?><BES xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="BES.xsd"><Baseline><Title>${xmlEscape(baselineName)}</Title><Description /><Relevance>true</Relevance><BaselineComponentCollection><BaselineComponentGroup>${componentsXml}</BaselineComponentGroup></BaselineComponentCollection></Baseline></BES>`;
      
      const postUrl = joinUrl(BIGFIX_BASE_URL, `/api/baselines/custom/${encodeURIComponent(targetSite)}`);
      
      const postResp = await axios.post(postUrl, finalXml, { ...bfAuthOpts, headers: { "Content-Type": "application/xml" } });
      let baselineId = null;
      const idMatch = String(postResp.data || "").match(/<ID>(\d+)<\/ID>/);
      if (idMatch) baselineId = idMatch[1];
      
      if (baselineId) {
         try {
            const pool = await getPool();
            await pool.request().input('BigFixID', sql.NVarChar(255), String(baselineId)).input('AssetName', sql.NVarChar(255), baselineName).input('AssetType', sql.NVarChar(50), 'Baseline').input('CreatedByRole', sql.NVarChar(50), userRole).query(`INSERT INTO dbo.AssetOwnership (BigFixID, AssetName, AssetType, CreatedByRole, CreatedAt) VALUES (@BigFixID, @AssetName, @AssetType, @CreatedByRole, SYSUTCDATETIME())`);
         } catch (dbErr) { }
      }
      res.json({ ok: true, baselineId, baselineName });
    } catch (e) {
      res.status(500).json({ ok: false, error: e.response?.data || e.message });
    }
  });
  
  app.post("/api/baseline/validate", async (req, res) => {
    const { baselineName } = req.body;
    if (!baselineName) return res.status(400).json({ ok: false, error: "baselineName required" });

    try {
      const safeName = baselineName.replace(/"/g, '\\"');
      const relevance = `(creation time of it as string & "||" & modification time of it as string) of bes baselines whose (name of it = "${safeName}")`;
      const url = `${joinUrl(BIGFIX_BASE_URL, "/api/query")}?output=json&relevance=${encodeURIComponent(relevance)}`;
      
      const bfAuthOpts = await getBfAuthContext(req, ctx); // SECURE CONTEXT
      const resp = await axios.get(url, { ...bfAuthOpts, headers: { Accept: "application/json" } });

      if (resp.status < 200 || resp.status >= 300) throw new Error(`BigFix query failed: ${resp.status}`);

      const result = resp.data?.result;
      const val = Array.isArray(result) ? result[0] : result;
      let warning = null;

      if (val && typeof val === 'string' && val.includes("||")) {
          const [cTimeStr, mTimeStr] = val.split("||");
          if (new Date(mTimeStr) > new Date(cTimeStr)) warning = `Baseline was modified on ${mTimeStr}`;
      }
      res.json({ ok: true, modified: !!warning, warning });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
  });
}

module.exports = { attachBaselineRoutes };